<?php
namespace Adminer;

const VERSION = "5.2.1";
