Copy `adminer.css` alongside Adminer PHP script to use an alternative design.
If the design supports dark mode then it should be named `adminer-dark.css`.

Gallery of designs (including external): https://www.adminer.org/#extras

See also: [plugins/designs.php](/plugins/designs.php)
