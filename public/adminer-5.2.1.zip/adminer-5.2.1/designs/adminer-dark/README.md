## Screenshot
![screenshot](https://www.adminer.org/static/screenshots/dark.png)
